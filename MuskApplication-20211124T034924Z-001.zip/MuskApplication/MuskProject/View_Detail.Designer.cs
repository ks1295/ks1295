﻿
namespace MuskProject
{
    partial class View_Detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workareaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supervisorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inspectorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.processDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.interventionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iscompletedDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.actiontakenDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.healthSafetyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.musk_ApplicationDataSet = new MuskProject.Musk_ApplicationDataSet();
            this.healthSafetyTableAdapter = new MuskProject.Musk_ApplicationDataSetTableAdapters.HealthSafetyTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.healthSafetyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.musk_ApplicationDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dateDataGridViewTextBoxColumn,
            this.siteDataGridViewTextBoxColumn,
            this.workareaDataGridViewTextBoxColumn,
            this.supervisorDataGridViewTextBoxColumn,
            this.inspectorDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.processDataGridViewTextBoxColumn,
            this.interventionDataGridViewTextBoxColumn,
            this.commentDataGridViewTextBoxColumn,
            this.iscompletedDataGridViewCheckBoxColumn,
            this.actiontakenDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.healthSafetyBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 69);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1155, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.Width = 150;
            // 
            // siteDataGridViewTextBoxColumn
            // 
            this.siteDataGridViewTextBoxColumn.DataPropertyName = "Site";
            this.siteDataGridViewTextBoxColumn.HeaderText = "Site";
            this.siteDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.siteDataGridViewTextBoxColumn.Name = "siteDataGridViewTextBoxColumn";
            this.siteDataGridViewTextBoxColumn.Width = 150;
            // 
            // workareaDataGridViewTextBoxColumn
            // 
            this.workareaDataGridViewTextBoxColumn.DataPropertyName = "Work_area";
            this.workareaDataGridViewTextBoxColumn.HeaderText = "Work_area";
            this.workareaDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.workareaDataGridViewTextBoxColumn.Name = "workareaDataGridViewTextBoxColumn";
            this.workareaDataGridViewTextBoxColumn.Width = 150;
            // 
            // supervisorDataGridViewTextBoxColumn
            // 
            this.supervisorDataGridViewTextBoxColumn.DataPropertyName = "Supervisor";
            this.supervisorDataGridViewTextBoxColumn.HeaderText = "Supervisor";
            this.supervisorDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.supervisorDataGridViewTextBoxColumn.Name = "supervisorDataGridViewTextBoxColumn";
            this.supervisorDataGridViewTextBoxColumn.Width = 150;
            // 
            // inspectorDataGridViewTextBoxColumn
            // 
            this.inspectorDataGridViewTextBoxColumn.DataPropertyName = "Inspector";
            this.inspectorDataGridViewTextBoxColumn.HeaderText = "Inspector";
            this.inspectorDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.inspectorDataGridViewTextBoxColumn.Name = "inspectorDataGridViewTextBoxColumn";
            this.inspectorDataGridViewTextBoxColumn.Width = 150;
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            this.sectionDataGridViewTextBoxColumn.Width = 150;
            // 
            // processDataGridViewTextBoxColumn
            // 
            this.processDataGridViewTextBoxColumn.DataPropertyName = "Process";
            this.processDataGridViewTextBoxColumn.HeaderText = "Process";
            this.processDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.processDataGridViewTextBoxColumn.Name = "processDataGridViewTextBoxColumn";
            this.processDataGridViewTextBoxColumn.Width = 150;
            // 
            // interventionDataGridViewTextBoxColumn
            // 
            this.interventionDataGridViewTextBoxColumn.DataPropertyName = "Intervention";
            this.interventionDataGridViewTextBoxColumn.HeaderText = "Intervention";
            this.interventionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.interventionDataGridViewTextBoxColumn.Name = "interventionDataGridViewTextBoxColumn";
            this.interventionDataGridViewTextBoxColumn.Width = 150;
            // 
            // commentDataGridViewTextBoxColumn
            // 
            this.commentDataGridViewTextBoxColumn.DataPropertyName = "Comment";
            this.commentDataGridViewTextBoxColumn.HeaderText = "Comment";
            this.commentDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.commentDataGridViewTextBoxColumn.Name = "commentDataGridViewTextBoxColumn";
            this.commentDataGridViewTextBoxColumn.Width = 150;
            // 
            // iscompletedDataGridViewCheckBoxColumn
            // 
            this.iscompletedDataGridViewCheckBoxColumn.DataPropertyName = "Iscompleted";
            this.iscompletedDataGridViewCheckBoxColumn.HeaderText = "Iscompleted";
            this.iscompletedDataGridViewCheckBoxColumn.MinimumWidth = 8;
            this.iscompletedDataGridViewCheckBoxColumn.Name = "iscompletedDataGridViewCheckBoxColumn";
            this.iscompletedDataGridViewCheckBoxColumn.Width = 150;
            // 
            // actiontakenDataGridViewTextBoxColumn
            // 
            this.actiontakenDataGridViewTextBoxColumn.DataPropertyName = "Action_taken";
            this.actiontakenDataGridViewTextBoxColumn.HeaderText = "Action_taken";
            this.actiontakenDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.actiontakenDataGridViewTextBoxColumn.Name = "actiontakenDataGridViewTextBoxColumn";
            this.actiontakenDataGridViewTextBoxColumn.Width = 150;
            // 
            // healthSafetyBindingSource
            // 
            this.healthSafetyBindingSource.DataMember = "HealthSafety";
            this.healthSafetyBindingSource.DataSource = this.musk_ApplicationDataSet;
            // 
            // musk_ApplicationDataSet
            // 
            this.musk_ApplicationDataSet.DataSetName = "Musk_ApplicationDataSet";
            this.musk_ApplicationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // healthSafetyTableAdapter
            // 
            this.healthSafetyTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(60, 276);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 42);
            this.button1.TabIndex = 1;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // View_Detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1753, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "View_Detail";
            this.Text = "View_Detail";
            this.Load += new System.EventHandler(this.View_Detail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.healthSafetyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.musk_ApplicationDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private Musk_ApplicationDataSet musk_ApplicationDataSet;
        private System.Windows.Forms.BindingSource healthSafetyBindingSource;
        private Musk_ApplicationDataSetTableAdapters.HealthSafetyTableAdapter healthSafetyTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn siteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn workareaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supervisorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn inspectorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn processDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn interventionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn iscompletedDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn actiontakenDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
    }
}