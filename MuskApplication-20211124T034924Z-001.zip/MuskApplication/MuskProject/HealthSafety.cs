﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MuskProject
{
    public partial class HealthSafety : Form
    {
        public HealthSafety()
        {
            InitializeComponent();
        }

        private void HealthSafety_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var healthsafety = new HealthSafetyModel();
            healthsafety.Date = this.textBox1.Text.ToString();
            healthsafety.Site = this.textBox2.Text.ToString();
            healthsafety.Work_area = this.textBox3.Text.ToString();
            healthsafety.Supervisor = this.textBox4.Text.ToString();
            healthsafety.Inspector = this.textBox5.Text.ToString();

            this.Hide();
            HealthSaftety1 hs1 = new HealthSaftety1(healthsafety);
            hs1.Show();
        }
        public class HealthSafetyModel
        {
            public string Date { get; set; }
            public string Site { get; set; }
            public string Work_area { get; set; }
            public string Supervisor { get; set; }
            public string Inspector { get; set; }
            public string Section { get; set; }
            public string Process { get; set; }
            public int Intervention { get; set; }
            public string Comment { get; set; }
            public bool Completed { get; set; }
            public string Action_taken { get; set; }
        }
    }
}
