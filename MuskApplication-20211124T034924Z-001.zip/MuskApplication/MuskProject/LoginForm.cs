﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace MuskProject
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=GUNJESH-SAINJU-\INSTANCE2016;Initial Catalog=Musk_Application; Integrated Security = SSPI;User ID=sa;password=");
            SqlDataAdapter sda = new SqlDataAdapter("Select Count (*) From Login where login_name='" + textBox1.Text + "' and login_password = '" + textBox2.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1" )
            {
                this.Hide();
                main ss = new main();
                ss.Show();


            }
         
            else
            {
                MessageBox.Show("Incorect Username and password, please try again");
            }



        }
    }
}
