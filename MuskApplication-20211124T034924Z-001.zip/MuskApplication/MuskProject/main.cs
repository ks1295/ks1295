﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MuskProject
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void contactus_Click(object sender, EventArgs e)
        {
            this.Hide();
            contact ct = new contact();
            ct.Show();


        }

        private void addaudit_Click(object sender, EventArgs e)
        {
            this.Hide();
            var hs = new HealthSafety();
            hs.Show();
        }

        private void viewaudit_Click(object sender, EventArgs e)
        {
            this.Hide();
            View_Detail vd = new View_Detail();
            vd.Show();
        }
    }
}
