﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MuskProject
{
    public partial class HealthSaftety1 : Form
    {
        HealthSafety.HealthSafetyModel hsform = new HealthSafety.HealthSafetyModel();
        bool isCompleted;
        public HealthSaftety1(HealthSafety.HealthSafetyModel hs)
        {
            this.hsform = hs;
            InitializeComponent();
        }

        private void HealthSaftety1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.hsform.Intervention = Convert.ToInt32(this.textBox1.Text);
            this.hsform.Comment = this.textBox2.Text.ToString();
            this.hsform.Action_taken = this.textBox3.Text.ToString();
            this.hsform.Section = this.comboBox1.SelectedItem.ToString();
            this.hsform.Process = this.comboBox2.SelectedItem.ToString();
            this.hsform.Completed = isCompleted;


            
            SqlConnection con = new SqlConnection(@"Data Source=GUNJESH-SAINJU-\INSTANCE2016;Initial Catalog=Musk_Application; Integrated Security = SSPI;User ID=sa;password=");
            con.Open();
            string sql=$"INSERT INTO HealthSafety (Date,Site,Work_area,Supervisor,Inspector,Section,Process,Intervention,Comment,Iscompleted,Action_taken) VALUES('{hsform.Date}','{hsform.Site}','{hsform.Work_area}','{hsform.Supervisor}','{hsform.Inspector}','{hsform.Section}','{hsform.Process}',{hsform.Intervention},'{hsform.Comment}','{hsform.Completed}','{hsform.Action_taken}')";
            
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show($"Form sucessfully saved");
            this.Hide();
            main m = new main();
            m.Show();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1.Checked)
            {
                this.isCompleted = true;
            }
            else
                this.isCompleted = false;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1.Checked)
            {
                this.isCompleted = true;
            }
            else
                this.isCompleted = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox1.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog opnfd = new OpenFileDialog();
            opnfd.Filter = "Select image(*.JpG; *.png; *.Gif)|*.JpG;*.png;*.Gif";
            if (opnfd.ShowDialog() == DialogResult.OK)
                pictureBox1.Image = Image.FromFile(opnfd.FileName);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
        }
    }
}
