﻿
namespace MuskProject
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addaudit = new System.Windows.Forms.Button();
            this.viewaudit = new System.Windows.Forms.Button();
            this.monthlystat = new System.Windows.Forms.Button();
            this.contactus = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // addaudit
            // 
            this.addaudit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.addaudit.Location = new System.Drawing.Point(160, 124);
            this.addaudit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addaudit.Name = "addaudit";
            this.addaudit.Size = new System.Drawing.Size(192, 141);
            this.addaudit.TabIndex = 0;
            this.addaudit.Text = "ADD AUDIT FORM";
            this.addaudit.UseVisualStyleBackColor = false;
            this.addaudit.Click += new System.EventHandler(this.addaudit_Click);
            // 
            // viewaudit
            // 
            this.viewaudit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.viewaudit.Location = new System.Drawing.Point(564, 124);
            this.viewaudit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.viewaudit.Name = "viewaudit";
            this.viewaudit.Size = new System.Drawing.Size(192, 141);
            this.viewaudit.TabIndex = 1;
            this.viewaudit.Text = "VIEW AUDIT FORM";
            this.viewaudit.UseVisualStyleBackColor = false;
            this.viewaudit.Click += new System.EventHandler(this.viewaudit_Click);
            // 
            // monthlystat
            // 
            this.monthlystat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.monthlystat.Location = new System.Drawing.Point(160, 339);
            this.monthlystat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.monthlystat.Name = "monthlystat";
            this.monthlystat.Size = new System.Drawing.Size(192, 141);
            this.monthlystat.TabIndex = 2;
            this.monthlystat.Text = "MONTHLY STATISTICS";
            this.monthlystat.UseVisualStyleBackColor = false;
            // 
            // contactus
            // 
            this.contactus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.contactus.Location = new System.Drawing.Point(564, 339);
            this.contactus.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.contactus.Name = "contactus";
            this.contactus.Size = new System.Drawing.Size(192, 141);
            this.contactus.TabIndex = 3;
            this.contactus.Text = "CONTACT US\r\n";
            this.contactus.UseVisualStyleBackColor = false;
            this.contactus.Click += new System.EventHandler(this.contactus_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(900, 562);
            this.Controls.Add(this.contactus);
            this.Controls.Add(this.monthlystat);
            this.Controls.Add(this.viewaudit);
            this.Controls.Add(this.addaudit);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "main";
            this.Text = "main";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button addaudit;
        private System.Windows.Forms.Button viewaudit;
        private System.Windows.Forms.Button monthlystat;
        private System.Windows.Forms.Button contactus;
    }
}