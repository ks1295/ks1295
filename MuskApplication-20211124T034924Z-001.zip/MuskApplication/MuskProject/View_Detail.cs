﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MuskProject
{
    public partial class View_Detail : Form
    {
        public View_Detail()
        {
            InitializeComponent();
        }

        private void View_Detail_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'musk_ApplicationDataSet.HealthSafety' table. You can move, or remove it, as needed.
            this.healthSafetyTableAdapter.Fill(this.musk_ApplicationDataSet.HealthSafety);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            main m = new main();
            m.Show();
        }
    }
}
